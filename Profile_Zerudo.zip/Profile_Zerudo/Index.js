// header toggle

let menubar = document.getElementById('menubar')

menubar.addEventListener('click', function(e) {
    document.querySelector('body').classList.toggle('mobile-nav-active');
    this.classList.toggle('fa-xmark');
})